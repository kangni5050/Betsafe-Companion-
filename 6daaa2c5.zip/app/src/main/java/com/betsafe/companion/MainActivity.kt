package com.betsafe.companion

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() { override fun onCreate(b: Bundle?) { super.onCreate(b); setContent { BetSafeApp() } } }

@Composable fun BetSafeApp() {
    var tab by remember { mutableStateOf(0) }
    MaterialTheme { Scaffold(bottomBar = { NavigationBar { listOf("Home","Add bet","Risk","Support").forEachIndexed { i, label -> NavigationBarItem(selected=tab==i,onClick={tab=i},icon={},label={Text(label)}) } } }) { p ->
        Box(Modifier.padding(p).fillMaxSize()) { when(tab) { 0 -> Home(); 1 -> AddBet(); 2 -> Risk(); else -> Support() } }
    }
}
@Composable fun Home() { Column(Modifier.padding(20.dp).verticalScroll(rememberScrollState())) { Text("BetSafe Companion", style=MaterialTheme.typography.headlineMedium); Text("A tool for safer decisions—not guaranteed predictions."); Spacer(Modifier.height(20.dp)); Card { Column(Modifier.padding(16.dp)) { Text("This week"); Text("Staked: 0.00"); Text("Net result: 0.00"); Text("No bets recorded") } }; Spacer(Modifier.height(16.dp)); Text("Safety check", style=MaterialTheme.typography.titleLarge); Text("Set a spending limit and take a break if betting feels difficult to control.") } }
@Composable fun AddBet() { var odds by remember { mutableStateOf("") }; var stake by remember { mutableStateOf("") }; Column(Modifier.padding(20.dp)) { Text("Record a bet", style=MaterialTheme.typography.headlineSmall); Text("This app does not place bets."); OutlinedTextField(odds,{odds=it},label={Text("Decimal odds")}); OutlinedTextField(stake,{stake=it},label={Text("Stake")}); Button(onClick={}) { Text("Save record") } } }
@Composable fun Risk() { var odds by remember { mutableStateOf("") }; Column(Modifier.padding(20.dp)) { Text("Risk calculator", style=MaterialTheme.typography.headlineSmall); OutlinedTextField(odds,{odds=it},label={Text("Total decimal odds")}); val p=odds.toDoubleOrNull()?.let { if(it>0) 100/it else 0.0 }; p?.let { Text("Approximate implied chance: %.1f%%".format(it)); Text("This is not a guarantee and does not account for bookmaker margin.") } } }
@Composable fun Support() { Column(Modifier.padding(20.dp).verticalScroll(rememberScrollState())) { Text("Support", style=MaterialTheme.typography.headlineSmall); Text("If you are chasing losses, hiding bets, borrowing money, or unable to stop, consider taking a break and speaking with someone you trust."); Spacer(Modifier.height(12.dp)); Text("Worldwide: Gambling Therapy provides free online support."); Text("If you may harm yourself, contact local emergency services now and stay with someone you trust.") } }
