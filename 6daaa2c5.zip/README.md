# BetSafe Companion Prototype

A local-first Android prototype for responsible betting tracking. It does not connect to bookmakers, place bets, or guarantee predictions.

Open this folder in Android Studio, sync Gradle, and run on an Android 8+ device or emulator.
