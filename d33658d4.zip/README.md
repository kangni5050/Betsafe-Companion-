# BetSafe Companion v0.2

An Android prototype based on the requested responsible-betting design. It includes a dashboard, local-session bet recording, odds risk calculator, weekly limit controls, cooling-off toggle, and support screen.

It does not place bets, connect to bookmakers, generate booking codes, or promise predictions. The current prototype keeps data in app memory; add Room or DataStore before public release.

Open in Android Studio, sync Gradle, and run on an Android 8+ device or emulator. Target API 36 is configured for current Google Play requirements.
