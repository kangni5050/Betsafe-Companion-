# Public release checklist

- Add persistent encrypted local storage.
- Add export and permanent deletion.
- Add validated country-specific support resources.
- Add privacy policy and accurate Google Play Data Safety form.
- Conduct accessibility and safety review.
- Complete closed testing required by Google Play.
- Build signed Android App Bundle.
- Review all wording to avoid encouraging gambling or guaranteeing outcomes.
