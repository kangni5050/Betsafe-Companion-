package com.betsafe.companion

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlin.math.round

class MainActivity: ComponentActivity(){override fun onCreate(s:Bundle?){super.onCreate(s);setContent{BetSafeApp()}}}

data class Bet(val event:String,val odds:Double,val stake:Double,val result:String)
@Composable fun BetSafeApp(){var screen by remember{mutableStateOf("Home")};var bets by remember{mutableStateOf(listOf<Bet>())};var limit by remember{mutableStateOf(0.0)};var cooling by remember{mutableStateOf(false)};MaterialTheme{Scaffold(bottomBar={NavigationBar{listOf("Home","Add bet","Risk","Limits","Support").forEach{n->NavigationBarItem(selected=screen==n,onClick={screen=n},icon={},label={Text(n)})}}}){p->Box(Modifier.padding(p)){when(screen){"Home"->Home(bets,limit,cooling);"Add bet"->AddBet({b->bets=bets+b;screen="Home"});"Risk"->Risk();"Limits"->Limits(limit,{limit=it},cooling,{cooling=it});else->Support()}}}}}
@Composable fun Home(b:List<Bet>,limit:Double,cooling:Boolean){val spent=b.sumOf{it.stake};Column(Modifier.padding(20.dp).verticalScroll(rememberScrollState())){Text("BetSafe Companion",style=MaterialTheme.typography.headlineMedium);Text("Private tool for safer decisions—not winning predictions.");Spacer(Modifier.height(16.dp));Card{Column(Modifier.padding(16.dp)){Text("Recorded bets: ${b.size}");Text("Staked: ${"%.2f".format(spent)}");Text(if(limit>0&&spent>=limit)"Limit reached" else if(cooling)"Cooling-off active" else "No warning")}};Spacer(Modifier.height(16.dp));Text("Never chase losses. A recorded bet is not a recommendation.")}}
@Composable fun AddBet(save:(Bet)->Unit){var event by remember{mutableStateOf("")};var odds by remember{mutableStateOf("")};var stake by remember{mutableStateOf("")};var result by remember{mutableStateOf("PENDING")};Column(Modifier.padding(20.dp).verticalScroll(rememberScrollState())){Text("Record a bet",style=MaterialTheme.typography.headlineSmall);Text("This app does not place or recommend bets.");OutlinedTextField(event,{event=it},label={Text("Event")});OutlinedTextField(odds,{odds=it},label={Text("Decimal odds")});OutlinedTextField(stake,{stake=it},label={Text("Stake")});Button(enabled=event.isNotBlank()&&(odds.toDoubleOrNull()?:0)>1&&(stake.toDoubleOrNull()?:0)>0,onClick={save(Bet(event,odds.toDouble(),stake.toDouble(),result))}){Text("Save record")}}}
@Composable fun Risk(){var odds by remember{mutableStateOf("")};Column(Modifier.padding(20.dp)){Text("Risk calculator",style=MaterialTheme.typography.headlineSmall);OutlinedTextField(odds,{odds=it},label={Text("Total decimal odds")});odds.toDoubleOrNull()?.takeIf{it>0}?.let{Text("Approximate implied chance: ${"%.1f".format(100/it)}%");Text("This is not a guarantee and excludes bookmaker margin.")}}}
@Composable fun Limits(limit:Double,set:(Double)->Unit,cooling:Boolean,setCooling:(Boolean)->Unit){var text by remember{mutableStateOf(if(limit>0)limit.toString() else "")};Column(Modifier.padding(20.dp)){Text("Limits and break",style=MaterialTheme.typography.headlineSmall);OutlinedTextField(text,{text=it},label={Text("Weekly spending limit")});Button(onClick={set(text.toDoubleOrNull()?:0.0)}){Text("Save limit")};Spacer(Modifier.height(12.dp));Button(onClick={setCooling(!cooling)}){Text(if(cooling)"End cooling-off" else "Start cooling-off")};Text("Lowering limits and taking breaks are safer than increasing stakes.")}}
@Composable fun Support(){Column(Modifier.padding(20.dp).verticalScroll(rememberScrollState())){Text("Support",style=MaterialTheme.typography.headlineSmall);Text("If you chase losses, hide bets, borrow money, or cannot stop, pause betting and speak with someone you trust.");Spacer(Modifier.height(12.dp));Text("Worldwide: Gambling Therapy offers free online support.");Text("If you may harm yourself, contact local emergency services immediately and stay with someone trusted.")}}
